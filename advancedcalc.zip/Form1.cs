﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // zarb
            string allowed_chars = "1234567890";
            string text = textBox1.Text;
            foreach (char t in text)
            {
                if (!allowed_chars.Contains(t))
                {
                   MessageBox.Show("Error! You just can enter numbers! (in first input)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            text = textBox2.Text;
            foreach (char t in text)
            {
                if (!allowed_chars.Contains(t))
                {
                    MessageBox.Show("Error! You just can enter numbers! (in second input)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            double first = double.Parse(textBox1.Text);
            double second = double.Parse(textBox2.Text);
            double answer = first * second;
            label1.Text = $"{answer}";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // tafriq
            string allowed_chars = "1234567890";
            string text = textBox1.Text;
            foreach (char t in text)
            {
                if (!allowed_chars.Contains(t))
                {
                    MessageBox.Show("Error! You just can enter numbers! (in first input)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            text = textBox2.Text;
            foreach (char t in text)
            {
                if (!allowed_chars.Contains(t))
                {
                    MessageBox.Show("Error! You just can enter numbers! (in second input)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            double first = double.Parse(textBox1.Text);
            double second = double.Parse(textBox2.Text);
            double answer = first - second;
            label1.Text = $"{answer}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // taghsim
            string allowed_chars = "1234567890";
            string text = textBox1.Text;
            foreach (char t in text)
            {
                if (!allowed_chars.Contains(t))
                {
                    MessageBox.Show("Error! You just can enter numbers! (in first input)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            text = textBox2.Text;
            foreach (char t in text)
            {
                if (!allowed_chars.Contains(t))
                {
                    MessageBox.Show("Error! You just can enter numbers! (in second input)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            double first = double.Parse(textBox1.Text);
            double second = double.Parse(textBox2.Text);
            double answer = (double)first / second;
            label1.Text = $"{answer}";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //jam
            string allowed_chars = "1234567890";
            string text = textBox1.Text;
            foreach (char t in text)
            {
                if (!allowed_chars.Contains(t))
                {
                    MessageBox.Show("Error! You just can enter numbers! (in first input)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            text = textBox2.Text;
            foreach (char t in text)
            {
                if (!allowed_chars.Contains(t))
                {
                    MessageBox.Show("Error! You just can enter numbers! (in second input)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            double first = double.Parse(textBox1.Text);
            double second = double.Parse(textBox2.Text);
            double answer = first + second;
            label1.Text = $"{answer}";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // clear
            textBox1.Text = textBox2.Text = "";
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // label
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // tb 1
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // tb2
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"{label1.Text}" , "Full Answer", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label1.Text = "";
        }
    }
}
